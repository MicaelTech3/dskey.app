package com.dsigner.dskey;

import junit.framework.TestCase;

public class MyApplicationTest extends TestCase {

}